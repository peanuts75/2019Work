
myfunc = () => {
    document.getElementById("gametext").innerHTML=document.getElementById("parsebox")}